// main.js
"use strict";

// @TODO: 웹 서버를 만들고 실행한다.
const port = 8080,
    express = require('express'),
    layouts = require('express-ejs-layouts'),
    homeController = require('./controllers/homeController'),
    errorController = require('./controllers/errorController'),
    app = express();

// #2 set
app.set("port", process.env.PORT || port);
app.set("view engine", "ejs");
// #3 use
app.use(layouts);
app.use(express.static('public'))//추가


// #4 get / post
app.get('/name/:myName', homeController.respondWithName);

//추가(에러 처리)
app.use(errorController.logErrors);
app.use(errorController.resNotFound);
app.use(errorController.resInternalError);

//#5 listen
app.listen(app.get("port"), () => {
    console.log(`Express at http://localhost:${app.get("port")}`)
})
