# 3. Express 웹 서버 만들기

이 과제는 3 부분으로 나뉩니다.

1. 'Express에서의 라우트' (9장)
2. '뷰와 템플릿의 연결' (10장)
3. '설정과 에러 처리' (11장)

## 과제 파일

- **3-express-webserver (Tests pass) `(12/12)`** _(4월 21일까지)_
  - [lesson-9](./lesson-9)
    - 9.7.EX.js `(2/2)`
    - /controllers/homeController.js `(2/2)`
  - [lesson-10](./lesson-10)
    - main.js `(2/2)`
    - /controllers/homeController.js `(2/2)`
  - [lesson-11](./lesson-11)
    - main.js `(2/2)`
    - /controllers/errorController.js `(2/2)`
